/**
 * This package has non null parameters and is documented.
 **/
@ParametersAreNonnullByDefault
package com.baz.lealtad.models;
// package models
import javax.annotation.ParametersAreNonnullByDefault;
