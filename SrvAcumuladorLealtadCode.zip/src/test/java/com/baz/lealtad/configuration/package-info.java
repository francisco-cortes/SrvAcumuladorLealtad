/**
 * This package has non null parameters and is documented.
 * Package: configuration
 * Author: Francisco Javier Cortes Torres
 * Este paquete tiene parametros no nulos i esta documentado
 **/
@ParametersAreNonnullByDefault
package com.baz.lealtad.configuration;
/*
package configuration
 */
import javax.annotation.ParametersAreNonnullByDefault;
