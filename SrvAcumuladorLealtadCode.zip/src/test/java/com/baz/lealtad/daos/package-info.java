/**
 * This package has non null parameters and is documented.
 **/
@ParametersAreNonnullByDefault
package com.baz.lealtad.daos;
// package daos
import javax.annotation.ParametersAreNonnullByDefault;
