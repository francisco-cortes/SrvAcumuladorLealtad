/**
 * This package has non null parameters and is documented.
 **/
@ParametersAreNonnullByDefault
package com.baz.lealtad.logger;
// package logger
import javax.annotation.ParametersAreNonnullByDefault;
