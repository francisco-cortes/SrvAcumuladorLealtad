package com.baz.lealtad.utils;

import com.baz.lealtad.configuration.ParametrerConfiguration;
import com.baz.lealtad.logger.LogServicio;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;
/**
 * <b>ClienteUnicoParserUtilTest</b>
 * @descripcion: Test Unitaros sobre el parceo del cliente unico
 * @autor: Francisco Javier Cortes Torres, Desarrollador
 * @ultimaModificacion: 31/10/22
 */
public class ClienteUnicoParserUtilTest {
  /*
  Constantes de respuesta
   */
  private static final String RESPUESTA_LABEL  = " Respuesta: ";
  private static final String ESPERADO_LABEL = " Esperado : ";
  private static final String INICIO_MENSAJE_LOG = "Parseo de Id Cliente, Entrada: ";
  private static final ClienteUnicoParserUtil clienteUnicoParserUtil = new ClienteUnicoParserUtil();
  private static final LogServicio log = new LogServicio();

  /**
   * <b>testClienteUnicoIdeal</b>
   * @descripcion: realiza el parseo con entrada ideal
   * @autor: Francisco Javier Cortes Torres, Desarrollador
   * @param:
   * @ultimaModificacion: 31/10/22
   */
  @DisplayName("Prueba unitaria cliente unico conforma xxxx-xxxx-xxxx-xxxx")
  @Test
  public void testClienteUnicoIdeal(){
    /*
    constantes
     */
    final String IDEAL = "0101-0127-4888-123";
    /*
    valor esperado despues de parsear
     */
    final String ESPERADO = "0101-0127-4888-123";

    String respuesta = clienteUnicoParserUtil.parsear(IDEAL, log);
    log.mensaje(ParametrerConfiguration.SYSTEM_NAME_TEST, INICIO_MENSAJE_LOG
      + "respuesta: " + respuesta);
    /*
    asierta si son iguales
     */
    assertTrue(respuesta.equals(ESPERADO));
  }

  /**
   * <b>testClienteDexNumerico</b>
   * @descripcion: realiza el parceo para un idcliente tipo dex
   * @autor: Francisco Javier Cortes Torres, Desarrollador
   * @ultimaModificacion: 31/10/22
   */
  @DisplayName("Prueba unitaria cliente unico conforma dex numerica de 7 a 10 digitos")
  @Test
  public void testClienteDexNumerico(){
    /*
    constantes
     */
    final String DEX = "159997207";
    /*
    valor esperado de respuesta
     */
    final String ESPERADO = "159997207";

    String respuesta = clienteUnicoParserUtil.parsear(DEX, log);
    log.mensaje(ParametrerConfiguration.SYSTEM_NAME_TEST, INICIO_MENSAJE_LOG + DEX + ESPERADO_LABEL + ESPERADO
      + RESPUESTA_LABEL + respuesta);
    /*
    acierta si son iguales
     */
    assertTrue(respuesta.equals(ESPERADO));
  }

  /**
   * <b>testClienteNumerico</b>
   * @descripcion: Realiza el parseo de los id clientes numericos de cliente unico
   * @autor: Francisco Javier Cortes Torres, Desarrollador
   * @ultimaModificacion: 31/10/22
   */
  @DisplayName("Prueba unitaria cliente unico con forma numerica de 12 digitos")
  @Test
  public void testClienteNumerico(){
    /*
    constantes
     */
    final String CU = "010120788844";
    /*
    valor esperado de respuesta
     */
    final String ESPERADO = "0101-2078-8844";

    String respuesta = clienteUnicoParserUtil.parsear(CU, log);
    log.mensaje(ParametrerConfiguration.SYSTEM_NAME_TEST, INICIO_MENSAJE_LOG + CU + ESPERADO + ESPERADO
      + RESPUESTA_LABEL + respuesta);
    /*
    acierta si es igual
     */
    assertTrue(respuesta.equals(ESPERADO));
  }

  /**
   * <b>testClienteEspecial</b>
   * @descripcion: Realiza el parseo con la forma especial sin cuartetos
   * @autor: Francisco Javier Cortes Torres, Desarrollador
   * @ultimaModificacion: 31/10/22
   */
  @DisplayName("Prueba unitaria cliente unico con forma x-x-xxxx-xxxxxx")
  @Test
  public void testClienteEspecial(){
    /*
    constantes
     */
    final String CU = "1-2-8757-25037";
    /*
    Valor esperado de respuesta
     */
    final String ESPERADO = "0102-8757-2503-7";

    String respuesta = clienteUnicoParserUtil.parsear(CU, log);
    log.mensaje(ParametrerConfiguration.SYSTEM_NAME_TEST, INICIO_MENSAJE_LOG + CU + ESPERADO_LABEL + ESPERADO
      + RESPUESTA_LABEL + respuesta);
    /*
    acierta si son iguales
     */
    assertTrue(respuesta.equals(ESPERADO));
  }

  /**
   * <b>testClienteEspecialDos</b>
   * @descripcion: Realiza el parseo para sucursales de 2 digistos de la forma especial
   * @autor: Francisco Javier Cortes Torres, Desarrollador
   * @ultimaModificacion: 31/10/22
   */
  @DisplayName("Prueba unitaria cliente unico con forma x-x-xx-xxxxxx")
  @Test
  public void testClienteEspecialDos(){
    /*
    constantes
     */
    final String CU = "11-11-87-2503712345678";
    final String ESPERADO = "1111-0087-2503-7123-4567-8";
    final String CU2 = "11-11-7-250371234567";
    final String ESPERADO2 = "1111-0007-2503-7123-4567";
    final String CU3 = "11-1-187-2503";
    final String ESPERADO3 = "1101-0187-2503-";

    String respuesta = ClienteUnicoParserUtil.parsear(CU, log);
    String respuesta2 = ClienteUnicoParserUtil.parsear(CU2, log);
    String respuesta3 = ClienteUnicoParserUtil.parsear(CU3, log);
    log.mensaje(ParametrerConfiguration.SYSTEM_NAME_TEST, INICIO_MENSAJE_LOG + CU + ESPERADO_LABEL + ESPERADO
      + RESPUESTA_LABEL + respuesta);
    log.mensaje(ParametrerConfiguration.SYSTEM_NAME_TEST, INICIO_MENSAJE_LOG + CU2 + ESPERADO_LABEL + ESPERADO2
      + RESPUESTA_LABEL + respuesta2);
    log.mensaje(ParametrerConfiguration.SYSTEM_NAME_TEST, INICIO_MENSAJE_LOG + CU3 + ESPERADO_LABEL + ESPERADO3
      + RESPUESTA_LABEL + respuesta3);
    assertTrue(respuesta.equals(ESPERADO)&& respuesta2.equals(ESPERADO2) && respuesta3.equals(ESPERADO3));
  }

  /**
   * <b>testClienteInvalido</b>
   * @descripcion: realiza el parseo para cadenas que no se puedan parsear
   * @autor: Francisco Javier Cortes Torres, Desarrollador
   * @param:
   * @ultimaModificacion: 31/10/22
   */
  @DisplayName("Prueba unitaria cliente unico con forma x-x-xx-xxxxxx")
  @Test
  public void testClienteInvalido(){
    /*
    constantes
     */
    final String CU = "cadena";
    /*
    se espera se regrese la misma cadena
     */
    final String ESPERADO = "cadena";

    String respuesta = ClienteUnicoParserUtil.parsear(CU, log);
    log.mensaje(ParametrerConfiguration.SYSTEM_NAME_TEST, INICIO_MENSAJE_LOG + CU + ESPERADO_LABEL + ESPERADO
      + RESPUESTA_LABEL + respuesta);
    assertTrue(respuesta.equals(ESPERADO));
  }

  /**
   * <b>testClienteNumericoOnceDigitos</b>
   * @descripcion: Realiza el parceo para cliente unico con 11 digitos, solo agrega un 0 en el tercer cuarteto
   * @autor: Francisco Javier Cortes Torres, Desarrollador
   * @param:
   * @ultimaModificacion: 31/10/22
   */
  @DisplayName("Prueba unitaria cliente unico con forma numerica de 11 digitos")
  @Test
  public void testClienteNumericoOnceDigitos(){
    /*
    constantes
     */
    final String CU = "01279953205";
    final String ESPERADO = "0127-9953-0205";

    String respuesta = clienteUnicoParserUtil.parsear(CU, log);
    log.mensaje(ParametrerConfiguration.SYSTEM_NAME_TEST, INICIO_MENSAJE_LOG + CU + ESPERADO + ESPERADO
      + RESPUESTA_LABEL + respuesta);
    assertTrue(respuesta.equals(ESPERADO));
  }

  /**
   * <b>testClienteNumericoDoceMas</b>
   * @descripcion: Realiza el parceo para cliente unico mayor a 12 digitos (maximo 16)
   * @autor: Francisco Javier Cortes Torres, Desarrollador
   * @param:
   * @ultimaModificacion: 31/10/22
   */
  @DisplayName("Prueba unitaria cliente unico con forma numerica de mas de 12 digitos")
  @Test
  public void testClienteNumericoDoceMas(){
    /*
    constantes
     */
    final String CU = "0101207888445726";
    final String ESPERADO = "0101-2078-8844-5726";

    /*
    el numero maximo de caracteres para clienteUnicoParcer es de 16 caracteres
     */
    String respuesta = clienteUnicoParserUtil.parsear(CU, log);
    log.mensaje(ParametrerConfiguration.SYSTEM_NAME_TEST, INICIO_MENSAJE_LOG + CU + ESPERADO + ESPERADO
      + RESPUESTA_LABEL + respuesta);
    /*
    acierta si son iguales
     */
    assertTrue(respuesta.equals(ESPERADO));
  }

}
